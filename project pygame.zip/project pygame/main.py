import csv
import pygame
import os
from pygame import mixer

pygame.init()
mixer.init()

W = 800
H = 640

screen = pygame.display.set_mode((W, H))
pygame.display.set_caption('Игра "Полёт в космос"')

clock = pygame.time.Clock()
FPS = 60

WHITE = (255, 255, 255)
BLUE = (55, 24, 160)

ROWS = 10
COLS = 70
TILE_SIZE = H // ROWS
TILE_TYPES = 20
GRAVITY = 0.75
ANIMATION_COOLDOWN = 100
ALIENS_ANIMATION_COOLDOWN = 300
scroll_screen = 0
bg_scroll = 0
to_scroll = 250
moving_left = False
moving_right = False
shoot = False

space_img = pygame.image.load('images/background/space.png').convert_alpha()
bullet_img = pygame.image.load('images/cosmonaut/bullet.png').convert_alpha()
heart_img = pygame.image.load('images/cosmonaut/heart.png').convert_alpha()
rocket_img = pygame.image.load('images/cosmonaut/rocket.png').convert_alpha()
main_menu_img = pygame.image.load('images/background/main_menu.jpg').convert_alpha()
start_button_img = pygame.image.load('images/buttons/start.jpg').convert_alpha()
exit_button_img = pygame.image.load('images/buttons/exit.jpg').convert_alpha()
restart_button_img = pygame.image.load('images/buttons/restart.jpg').convert_alpha()
exit1_small_img = pygame.image.load('images/buttons/exit1.jpg').convert_alpha()
exit2_img = pygame.image.load('images/buttons/exit2.jpg').convert_alpha()
level_button_img = pygame.image.load('images/buttons/next level.jpg').convert_alpha()
coin_img = pygame.image.load('images/coin/0.png').convert_alpha()
coin_img = pygame.transform.scale(coin_img, (int(coin_img.get_width() * 0.7), int(coin_img.get_height() * 0.7)))

coin_animation_lst = []
num_of_files = len(os.listdir(f'images/coin'))
for i in range(num_of_files):
    img = pygame.image.load(f'images/coin/{i}.png').convert_alpha()
    coin_animation_lst.append(img)

tiles_lst = []
for i in range(TILE_TYPES):
    img = pygame.image.load(f'images/tiles/{i}.png')
    img = pygame.transform.scale(img, (TILE_SIZE, TILE_SIZE))
    tiles_lst.append(img)

count_levels = 2
level_number = 1
start_game = False
start_transition = False

pygame.mixer.music.load('music/space theme.mp3')
pygame.mixer.music.set_volume(0.2)
pygame.mixer.music.play(-1)
jump_sound = pygame.mixer.Sound('music/jump.mp3')
jump_sound.set_volume(0.5)
shoot_sound = pygame.mixer.Sound('music/shoot.mp3')
shoot_sound.set_volume(0.5)
hit_sound = pygame.mixer.Sound('music/hit.mp3')
hit_sound.set_volume(0.5)
coin_sound = pygame.mixer.Sound('music/coin.mp3')
coin_sound.set_volume(0.5)


def load_level():
    alien_group.empty()
    bullets.empty()
    boxes.empty()
    thorns.empty()
    rockets.empty()
    coins.empty()
    map_ = []
    for k in range(ROWS):
        k = [-1] * COLS
        map_.append(k)
    return map_


def draw_text(text, text_colour, text_size, x, y):
    f = pygame.font.Font(None, text_size)
    im = f.render(text, True, text_colour)
    screen.blit(im, (x, y))


class Cosmonaut(pygame.sprite.Sprite):
    def __init__(self, character, x, y, scale, speed, health):
        pygame.sprite.Sprite.__init__(self)
        self.character = character
        self.alive = True
        image = pygame.image.load(f'images/{self.character}/0.png').convert_alpha()
        self.image = pygame.transform.scale(image, (int(image.get_width() * scale), int(image.get_height() * scale)))
        self.rect = self.image.get_rect(center=(x, y))
        self.health = health
        self.direction = 1
        self.flip = False
        self.animation_lst = []
        self.animation_index = 0
        self.character_running = False
        self.speed = speed
        self.jump = False
        self.in_air = True
        self.jump_speed = 0
        self.shoot_cooldown = 0
        self.damage_cooldown = 0
        self.score = 0
        self.max_score = 0
        self.coin_number = 0
        self.update_time = pygame.time.get_ticks()
        self.aliens_movement_timer = 0
        self.number_of_files = len(os.listdir(f'images/{self.character}/Run'))
        for i in range(self.number_of_files):
            im = pygame.image.load(f'images/{self.character}/Run/{i}.png').convert_alpha()
            im = pygame.transform.scale(im, (int(im.get_width() * scale), int(im.get_height() * scale)))
            self.animation_lst.append(im)
        self.width = self.image.get_width()
        self.height = self.image.get_height()

    def update(self):
        self.check_alive()
        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1
        if self.damage_cooldown > 0:
            self.damage_cooldown -= 1

    def moving(self, move_left, move_right):
        you_win = False
        scroll = 0
        dx = 0
        dy = 0
        if move_left:
            dx -= self.speed
            self.flip = True
            self.direction = -1

        if move_right:
            dx = self.speed
            self.flip = False
            self.direction = 1

        if self.jump and not self.in_air:
            self.jump_speed = -14
            self.jump = False
            self.in_air = True

        self.jump_speed += GRAVITY
        if self.jump_speed > 10:
            self.jump_speed = 10
        dy += self.jump_speed

        for tile in new_map.platforms_lst:
            if tile[1].colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                dx = 0
            if tile[1].colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                if self.jump_speed < 0:
                    self.jump_speed = 0
                    dy = tile[1].bottom - self.rect.top
                elif self.jump_speed >= 0:
                    self.jump_speed = 0
                    self.in_air = False
                    dy = tile[1].top - self.rect.bottom
        if self.character == 'cosmonaut':
            if self.rect.right + dx > W or self.rect.left + dx < 0:
                dx = 0

        self.rect.x += dx
        self.rect.y += dy

        if self.character == 'cosmonaut':
            if pygame.sprite.spritecollide(self, thorns, False):
                if self.damage_cooldown == 0:
                    hit_sound.play()
                    self.health -= 1
                    self.damage_cooldown = 100
            if pygame.sprite.spritecollide(self, alien_group, False):
                if self.damage_cooldown == 0:
                    hit_sound.play()
                    self.health -= 1
                    self.damage_cooldown = 100
            if pygame.sprite.spritecollide(self, rockets, False):
                player.speed = 0
                you_win = True
            if self.rect.bottom > H:
                self.health = 0

        if self.character == 'cosmonaut':
            if (self.rect.right > W - to_scroll and (bg_scroll < (new_map.level_length * TILE_SIZE) - W)) \
                    or (self.rect.left < to_scroll and bg_scroll > abs(dx)):
                self.rect.x -= dx
                scroll = -dx
        return scroll, you_win

    def shoot(self):
        if self.shoot_cooldown == 0:
            self.shoot_cooldown = 20
            bullet = Shoot(self.rect.centerx + (0.5 * self.rect.size[0] * self.direction), self.rect.centery,
                           player.direction)
            bullets.add(bullet)
            shoot_sound.play()

    def aliens_movement(self):
        if player.alive:
            if self.direction == 1:
                aliens_moving_right = True
            else:
                aliens_moving_right = False
            aliens_moving_left = not aliens_moving_right
            self.moving(aliens_moving_left, aliens_moving_right)
            self.image = self.animation_lst[self.animation_index]
            if pygame.time.get_ticks() - self.update_time > ALIENS_ANIMATION_COOLDOWN:
                self.update_time = pygame.time.get_ticks()
                self.animation_index += 1
            if self.animation_index >= len(self.animation_lst):
                self.animation_index = 0
            self.aliens_movement_timer += 1
            if self.aliens_movement_timer > 35:
                self.direction *= -1
                self.aliens_movement_timer *= -1
            self.rect.x += scroll_screen

    def update_animation(self):
        if self.character_running and not self.in_air:
            self.image = self.animation_lst[self.animation_index]
        else:
            self.animation_index = 0
            self.image = self.animation_lst[self.animation_index]
        if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
            self.update_time = pygame.time.get_ticks()
            self.animation_index += 1
        if self.animation_index >= len(self.animation_lst):
            self.animation_index = 0

    def check_alive(self):
        if self.health <= 0:
            self.health = 0
            self.speed = 0
            self.alive = False
            self.kill()

    def draw(self):
        screen.blit(pygame.transform.flip(self.image, self.flip, False), self.rect)


class Shoot(pygame.sprite.Sprite):
    def __init__(self, x, y, direction):
        pygame.sprite.Sprite.__init__(self)
        self.speed = 10
        self.image = bullet_img
        self.rect = self.image.get_rect(center=(x, y))
        self.direction = direction

    def update(self):
        self.rect.x += (self.speed * self.direction) + scroll_screen
        if self.rect.right < 0 or self.rect.left > W:
            self.kill()

        for tile in new_map.platforms_lst:
            if tile[1].colliderect(self.rect):
                self.kill()

        for al in alien_group:
            if pygame.sprite.spritecollide(al, bullets, False):
                if al.alive:
                    al.health -= 1
                    player.score += 100
                    self.kill()


class Map:
    def __init__(self):
        self.platforms_lst = []
        self.level_length = 0

    def create_level(self, map):
        self.level_length = len(map[0])
        for y, row in enumerate(map):
            for x, tile in enumerate(row):
                if tile != -1:
                    image = tiles_lst[tile]
                    image_rect = image.get_rect()
                    image_rect.x = x * TILE_SIZE
                    image_rect.y = y * TILE_SIZE
                    tile_lst = (image, image_rect)
                    if (0 <= tile <= 10) or tile == 15:
                        self.platforms_lst.append(tile_lst)
                    elif tile == 14:
                        thorn = Thorns(image, x * TILE_SIZE, y * TILE_SIZE)
                        thorns.add(thorn)
                    elif 11 <= tile <= 13:
                        box = Boxes(image, x * TILE_SIZE, y * TILE_SIZE)
                        boxes.add(box)
                    elif tile == 16:
                        alien = Cosmonaut('alien', x * TILE_SIZE, y * TILE_SIZE, 2, 2, 1)
                        alien_group.add(alien)
                    elif tile == 17:
                        hero = Cosmonaut('cosmonaut', x * TILE_SIZE, y * TILE_SIZE, 3.5, 5, 3)
                    elif tile == 18:
                        rocket = Finish(x * TILE_SIZE, y * TILE_SIZE)
                        rockets.add(rocket)
                    elif tile == 19:
                        coin = Coins(x * TILE_SIZE + (TILE_SIZE // 2), y * TILE_SIZE + (TILE_SIZE // 2))
                        coins.add(coin)
        hero.max_score = len(alien_group) * 100
        return hero

    def draw(self):
        for j in self.platforms_lst:
            j[1][0] += scroll_screen
            screen.blit(j[0], j[1])


class Boxes(pygame.sprite.Sprite):
    def __init__(self, img, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def update(self):
        self.rect.x += scroll_screen


class Thorns(pygame.sprite.Sprite):
    def __init__(self, img, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def update(self):
        self.rect.x += scroll_screen


class Finish(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = rocket_img
        self.image = pygame.transform.scale(self.image,
                                            (int(self.image.get_width() * 1.5), int(self.image.get_height() * 1.5)))
        self.rect = self.image.get_rect()
        self.rect.midtop = (x + TILE_SIZE // 2, y + (TILE_SIZE - self.image.get_height()))

    def update(self):
        self.rect.x += scroll_screen


class Coins(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('images/coin/0.png').convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.update_time = pygame.time.get_ticks()
        self.animation_index = 0
        self.coins_animation_cooldown = 150

    def update(self):
        self.rect.x += scroll_screen
        if player.alive:
            self.image = coin_animation_lst[self.animation_index]
            if pygame.time.get_ticks() - self.update_time > self.coins_animation_cooldown:
                self.update_time = pygame.time.get_ticks()
                self.animation_index += 1
            if self.animation_index >= len(coin_animation_lst):
                self.animation_index = 0

        if pygame.sprite.collide_rect(self, player):
            coin_sound.play()
            player.coin_number += 1
            self.kill()


class Buttons(pygame.sprite.Sprite):
    def __init__(self, img, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)
        self.clicked = False

    def draw(self):
        action = False
        pos = pygame.mouse.get_pos()
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and not self.clicked:
                action = True
                self.clicked = True
            if pygame.mouse.get_pressed()[0] == 0:
                self.clicked = False
        screen.blit(self.image, (self.rect.x, self.rect.y))
        return action


class Transition:
    def __init__(self, colour, speed, kind):
        self.colour = colour
        self.speed = speed
        self.kind = kind
        self.count = 0

    def make_transition(self):
        complete = False
        self.count += self.speed
        if self.kind == 1:
            pygame.draw.rect(screen, self.colour, (0, 0, W, 0 + self.count))
        elif self.kind == 2:
            pygame.draw.rect(screen, self.colour, (0 - self.count, 0, W // 2, H))
            pygame.draw.rect(screen, self.colour, (W // 2 + self.count, 0, W, H))
        if self.count >= W:
            complete = True
        return complete


alien_group = pygame.sprite.Group()
bullets = pygame.sprite.Group()
boxes = pygame.sprite.Group()
thorns = pygame.sprite.Group()
rockets = pygame.sprite.Group()
coins = pygame.sprite.Group()
restart_transition = Transition(BLUE, 7, 1)
levels_transition = Transition(BLUE, 6, 2)

map = []
for row in range(ROWS):
    r = [-1] * COLS
    map.append(r)
with open(f'level_{level_number}.csv', newline='') as csvfile:
    reader = csv.reader(csvfile, delimiter=',')
    for x, row in enumerate(reader):
        for y, tile in enumerate(row):
            map[x][y] = int(tile)

new_map = Map()
player = new_map.create_level(map)
start_button = Buttons(start_button_img, 100, 100)
exit_button = Buttons(exit_button_img, 100, 220)
exit1_button = Buttons(exit1_small_img, (W // 2) + 15, (H // 2) + 25)
restart_button = Buttons(restart_button_img, (W // 2) - 158, (H // 2) - 25)
level_button = Buttons(level_button_img, (W // 2) - 158, (H // 2) + 25)
exit2_button = Buttons(exit2_img, (W // 2) - 107, (H // 2) + 30)
exit3_button = Buttons(exit1_small_img, (W // 2) + 15, (H // 2) - 25)

running = True
while running:
    clock.tick(FPS)
    if start_game:
        screen.fill(pygame.Color("white"))
        screen.blit(space_img, (0, 0))
        new_map.draw()
        draw_text(f'SCORE: {player.score}', WHITE, 26, 700, 40)
        screen.blit(coin_img, (700, 10))
        draw_text(f':  {player.coin_number}', WHITE, 26, 730, 15)
        draw_text(f'УРОВЕНЬ {level_number}', WHITE, 32, 325, 16)

        for n in range(player.health):
            screen.blit(heart_img, (10 + (n * 37), 15))

        for alien in alien_group:
            alien.update()
            alien.draw()
            alien.aliens_movement()

        bullets.update()
        boxes.update()
        thorns.update()
        rockets.update()
        coins.update()
        boxes.draw(screen)
        thorns.draw(screen)
        rockets.draw(screen)
        bullets.draw(screen)
        coins.draw(screen)
        player.update()
        player.update_animation()
        player.draw()

        if start_transition:
            if levels_transition.make_transition():
                start_transition = False
                levels_transition.count = 0

        if player.alive:
            scroll_screen, you_win = player.moving(moving_left, moving_right)
            bg_scroll -= scroll_screen
            if shoot:
                player.shoot()
            if moving_left or moving_right:
                player.character_running = True
            else:
                player.character_running = False
            if you_win:
                if restart_transition.make_transition():
                    draw_text('Уровень пройден!', WHITE, 65, 200, 130)
                    draw_text('Вы набрали', WHITE, 45, 300, 200)
                    draw_text(f'очки: {player.score} (макс. {player.max_score})', WHITE, 40, 320, 250)
                    draw_text(f'звёзды: {player.coin_number}', WHITE, 40, 320, 290)
                    if (level_number + 1) <= count_levels:
                        if exit1_button.draw():
                            running = False
                        if level_button.draw():
                            restart_transition.count = 0
                            start_transition = True
                            level_number += 1
                            bg_scroll = 0
                            map = load_level()
                            if level_number <= count_levels:
                                with open(f'level_{level_number}.csv', newline='') as csvfile:
                                    reader = csv.reader(csvfile, delimiter=',')
                                    for x, row in enumerate(reader):
                                        for y, tile in enumerate(row):
                                            map[x][y] = int(tile)
                                new_map = Map()
                                player = new_map.create_level(map)
                    elif (level_number + 1) > count_levels:
                        if exit2_button.draw():
                            running = False

        else:
            scroll_screen = 0
            if restart_transition.make_transition():
                draw_text('Вы проиграли!', WHITE, 60, 250, 200)
                if exit3_button.draw():
                    running = False
                if restart_button.draw():
                    restart_transition.count = 0
                    start_transition = True
                    bg_scroll = 0
                    map = load_level()
                    with open(f'level_{level_number}.csv', newline='') as csvfile:
                        reader = csv.reader(csvfile, delimiter=',')
                        for x, row in enumerate(reader):
                            for y, tile in enumerate(row):
                                map[x][y] = int(tile)
                    new_map = Map()
                    player = new_map.create_level(map)
    else:
        screen.blit(main_menu_img, (0, 0))
        if start_button.draw():
            start_game = True
        if exit_button.draw():
            running = False

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                moving_right = True
            if event.key == pygame.K_LEFT:
                moving_left = True
            if event.key == pygame.K_ESCAPE:
                running = False
            if event.key == pygame.K_UP and player.alive:
                player.jump = True
                jump_sound.play()
            if event.key == pygame.K_SPACE:
                shoot = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_RIGHT:
                moving_right = False
            if event.key == pygame.K_LEFT:
                moving_left = False
            if event.key == pygame.K_SPACE:
                shoot = False

    pygame.display.update()
pygame.quit()
